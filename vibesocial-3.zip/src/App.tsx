/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Home, 
  Search, 
  PlusSquare, 
  MessageCircle, 
  User, 
  Heart, 
  Share2, 
  MoreHorizontal, 
  Camera, 
  Film, 
  Send,
  ArrowLeft,
  Check,
  X,
  Image as ImageIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// --- Types ---
interface UserType {
  id: number;
  username: string;
  display_name: string;
  profile_pic: string;
  bio: string;
}

interface PostType {
  id: number;
  user_id: number;
  type: 'post' | 'reel';
  content_url: string;
  caption: string;
  display_name: string;
  profile_pic: string;
  username: string;
  created_at: string;
}

interface StoryType {
  id: number;
  user_id: number;
  content_url: string;
  display_name: string;
  profile_pic: string;
}

interface MessageType {
  id: number;
  sender_id: number;
  receiver_id: number;
  text: string;
  created_at: string;
}

// --- Components ---

const Sidebar = ({ activeTab, setActiveTab, currentUser }: { activeTab: string, setActiveTab: (t: string) => void, currentUser: UserType | null }) => {
  const tabs = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'search', icon: Search, label: 'Search' },
    { id: 'create', icon: PlusSquare, label: 'Create' },
    { id: 'messages', icon: MessageCircle, label: 'Messages' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="fixed bottom-0 left-0 w-full bg-white border-t md:border-t-0 md:border-r md:w-64 md:h-screen md:flex-col md:static flex justify-around items-center p-2 z-50">
      <div className="hidden md:block p-6 mb-8">
        <h1 className="text-2xl font-bold tracking-tighter text-indigo-600">VibeSocial</h1>
      </div>
      <div className="flex md:flex-col w-full gap-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-4 p-3 rounded-xl transition-all ${
              activeTab === tab.id ? 'bg-indigo-50 text-indigo-600 font-semibold' : 'hover:bg-gray-50 text-gray-600'
            }`}
          >
            <tab.icon size={24} />
            <span className="hidden md:block">{tab.label}</span>
          </button>
        ))}
      </div>
      {currentUser && (
        <div className="hidden md:flex mt-auto p-4 items-center gap-3 border-t w-full">
          <img src={currentUser.profile_pic} className="w-10 h-10 rounded-full object-cover border" alt="" />
          <div className="overflow-hidden">
            <p className="text-sm font-semibold truncate">{currentUser.display_name}</p>
            <p className="text-xs text-gray-500 truncate">@{currentUser.username}</p>
          </div>
        </div>
      )}
    </div>
  );
};

const StoryBar = ({ stories, onAddStory }: { stories: StoryType[], onAddStory: () => void }) => {
  return (
    <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
      <button 
        onClick={onAddStory}
        className="flex flex-col items-center gap-1 flex-shrink-0"
      >
        <div className="w-16 h-16 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center bg-gray-50 hover:bg-gray-100 transition-colors">
          <PlusSquare size={24} className="text-gray-400" />
        </div>
        <span className="text-xs text-gray-500">Your Story</span>
      </button>
      {stories.map((story) => (
        <div key={story.id} className="flex flex-col items-center gap-1 flex-shrink-0">
          <div className="w-16 h-16 rounded-full p-0.5 border-2 border-indigo-500">
            <img src={story.profile_pic} className="w-full h-full rounded-full object-cover" alt="" />
          </div>
          <span className="text-xs text-gray-600 truncate w-16 text-center">{story.display_name}</span>
        </div>
      ))}
    </div>
  );
};

const Post = ({ post }: { post: PostType, key?: React.Key }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border rounded-2xl overflow-hidden mb-6 shadow-sm"
    >
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src={post.profile_pic} className="w-10 h-10 rounded-full object-cover border" alt="" />
          <div>
            <p className="text-sm font-semibold">{post.display_name}</p>
            <p className="text-xs text-gray-500">@{post.username}</p>
          </div>
        </div>
        <button className="text-gray-400 hover:text-gray-600">
          <MoreHorizontal size={20} />
        </button>
      </div>
      
      {post.type === 'reel' ? (
        <div className="aspect-[9/16] bg-black relative flex items-center justify-center">
          <video 
            src={post.content_url} 
            className="w-full h-full object-contain" 
            controls
            loop
          />
          <div className="absolute top-4 right-4 bg-black/50 text-white p-1 rounded-md">
            <Film size={16} />
          </div>
        </div>
      ) : (
        <div className="aspect-square bg-gray-100">
          <img src={post.content_url} className="w-full h-full object-cover" alt="" />
        </div>
      )}

      <div className="p-4">
        <div className="flex gap-4 mb-3">
          <button className="hover:text-red-500 transition-colors"><Heart size={24} /></button>
          <button className="hover:text-indigo-500 transition-colors"><MessageCircle size={24} /></button>
          <button className="hover:text-indigo-500 transition-colors"><Share2 size={24} /></button>
        </div>
        <p className="text-sm">
          <span className="font-semibold mr-2">{post.username}</span>
          {post.caption}
        </p>
        <p className="text-[10px] text-gray-400 mt-2 uppercase tracking-wider">
          {new Date(post.created_at).toLocaleDateString()}
        </p>
      </div>
    </motion.div>
  );
};

const CreateModal = ({ isOpen, onClose, onPost, currentUser }: { isOpen: boolean, onClose: () => void, onPost: (type: 'post' | 'reel', url: string, caption: string) => void, currentUser: UserType | null }) => {
  const [type, setType] = useState<'post' | 'reel'>('post');
  const [caption, setCaption] = useState('');
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (preview) {
      onPost(type, preview, caption);
      setPreview(null);
      setCaption('');
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-3xl w-full max-w-lg overflow-hidden"
      >
        <div className="p-4 border-b flex justify-between items-center">
          <h2 className="text-lg font-bold">Create New {type === 'post' ? 'Post' : 'Reel'}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full"><X size={20} /></button>
        </div>
        
        <div className="p-6">
          <div className="flex gap-4 mb-6">
            <button 
              onClick={() => setType('post')}
              className={`flex-1 py-3 rounded-xl border-2 flex items-center justify-center gap-2 transition-all ${type === 'post' ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-gray-100 text-gray-500'}`}
            >
              <ImageIcon size={20} /> Post
            </button>
            <button 
              onClick={() => setType('reel')}
              className={`flex-1 py-3 rounded-xl border-2 flex items-center justify-center gap-2 transition-all ${type === 'reel' ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-gray-100 text-gray-500'}`}
            >
              <Film size={20} /> Reel
            </button>
          </div>

          <div 
            onClick={() => fileInputRef.current?.click()}
            className="aspect-video bg-gray-50 border-2 border-dashed border-gray-200 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors overflow-hidden relative"
          >
            {preview ? (
              type === 'post' ? (
                <img src={preview} className="w-full h-full object-cover" alt="" />
              ) : (
                <video src={preview} className="w-full h-full object-contain" />
              )
            ) : (
              <>
                <Camera size={40} className="text-gray-300 mb-2" />
                <p className="text-sm text-gray-500">Click to upload {type === 'post' ? 'image' : 'video'}</p>
              </>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              className="hidden" 
              accept={type === 'post' ? "image/*" : "video/*"} 
            />
          </div>

          <textarea 
            placeholder="Write a caption..."
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            className="w-full mt-6 p-4 bg-gray-50 rounded-2xl border-none focus:ring-2 focus:ring-indigo-500 resize-none h-24"
          />

          <button 
            disabled={!preview}
            onClick={handleSubmit}
            className="w-full mt-6 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            Share
          </button>
        </div>
      </motion.div>
    </div>
  );
};

const SearchPage = ({ onFollow }: { onFollow: (id: number) => void }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<UserType[]>([]);

  useEffect(() => {
    if (query.length > 1) {
      fetch(`/api/users/search?q=${query}`)
        .then(res => res.json())
        .then(setResults);
    } else {
      setResults([]);
    }
  }, [query]);

  return (
    <div className="max-w-2xl mx-auto p-4">
      <div className="relative mb-8">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
        <input 
          type="text" 
          placeholder="Search users..." 
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-4 bg-white border rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm"
        />
      </div>

      <div className="space-y-4">
        {results.map(user => (
          <div key={user.id} className="bg-white p-4 rounded-2xl border flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-4">
              <img src={user.profile_pic} className="w-12 h-12 rounded-full object-cover border" alt="" />
              <div>
                <p className="font-bold">{user.display_name}</p>
                <p className="text-sm text-gray-500">@{user.username}</p>
              </div>
            </div>
            <button 
              onClick={() => onFollow(user.id)}
              className="px-6 py-2 bg-indigo-600 text-white rounded-xl text-sm font-semibold hover:bg-indigo-700"
            >
              Follow
            </button>
          </div>
        ))}
        {query && results.length === 0 && (
          <p className="text-center text-gray-500 mt-10">No users found.</p>
        )}
      </div>
    </div>
  );
};

const ProfilePage = ({ user, onUpdate }: { user: UserType, onUpdate: (u: Partial<UserType>) => void }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({ display_name: user.display_name, bio: user.bio, profile_pic: user.profile_pic });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleProfilePicChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditData({ ...editData, profile_pic: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    onUpdate(editData);
    setIsEditing(false);
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <div className="bg-white rounded-3xl border p-8 shadow-sm">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="relative group">
            <img src={editData.profile_pic} className="w-32 h-32 md:w-40 md:h-40 rounded-full object-cover border-4 border-white shadow-lg" alt="" />
            {isEditing && (
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Camera size={24} />
              </button>
            )}
            <input type="file" ref={fileInputRef} onChange={handleProfilePicChange} className="hidden" accept="image/*" />
          </div>
          
          <div className="flex-1 text-center md:text-left">
            {isEditing ? (
              <div className="space-y-4">
                <input 
                  type="text" 
                  value={editData.display_name} 
                  onChange={(e) => setEditData({...editData, display_name: e.target.value})}
                  className="text-2xl font-bold bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 w-full"
                />
                <textarea 
                  value={editData.bio} 
                  onChange={(e) => setEditData({...editData, bio: e.target.value})}
                  className="text-gray-600 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 w-full h-20"
                />
                <div className="flex gap-2">
                  <button onClick={handleSave} className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-semibold">Save</button>
                  <button onClick={() => setIsEditing(false)} className="bg-gray-100 text-gray-600 px-6 py-2 rounded-xl font-semibold">Cancel</button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-center md:justify-start gap-4 mb-2">
                  <h2 className="text-3xl font-bold">{user.display_name}</h2>
                  <button 
                    onClick={() => setIsEditing(true)}
                    className="px-4 py-1.5 border rounded-lg text-sm font-semibold hover:bg-gray-50"
                  >
                    Edit Profile
                  </button>
                </div>
                <p className="text-gray-500 mb-4">@{user.username}</p>
                <p className="text-gray-700 max-w-md">{user.bio}</p>
                
                <div className="flex gap-8 mt-6 justify-center md:justify-start">
                  <div className="text-center">
                    <p className="font-bold text-xl">124</p>
                    <p className="text-xs text-gray-500 uppercase tracking-widest">Posts</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-xl">1.2k</p>
                    <p className="text-xs text-gray-500 uppercase tracking-widest">Followers</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-xl">842</p>
                    <p className="text-xs text-gray-500 uppercase tracking-widest">Following</p>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const MessagesPage = ({ currentUser }: { currentUser: UserType }) => {
  const [users, setUsers] = useState<UserType[]>([]);
  const [selectedUser, setSelectedUser] = useState<UserType | null>(null);
  const [messages, setMessages] = useState<MessageType[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch('/api/users/search?q=')
      .then(res => res.json())
      .then(data => setUsers(data.filter((u: UserType) => u.id !== currentUser.id)));
  }, [currentUser.id]);

  useEffect(() => {
    if (selectedUser) {
      fetch(`/api/messages/${currentUser.id}/${selectedUser.id}`)
        .then(res => res.json())
        .then(setMessages);
    }
  }, [selectedUser, currentUser.id]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!newMessage.trim() || !selectedUser) return;
    
    const res = await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sender_id: currentUser.id,
        receiver_id: selectedUser.id,
        text: newMessage
      })
    });

    if (res.ok) {
      setMessages([...messages, { id: Date.now(), sender_id: currentUser.id, receiver_id: selectedUser.id, text: newMessage, created_at: new Date().toISOString() }]);
      setNewMessage('');
    }
  };

  return (
    <div className="max-w-5xl mx-auto h-[calc(100vh-120px)] flex bg-white rounded-3xl border overflow-hidden shadow-sm">
      <div className="w-1/3 border-r flex flex-col">
        <div className="p-6 border-b">
          <h2 className="text-xl font-bold">Messages</h2>
        </div>
        <div className="flex-1 overflow-y-auto">
          {users.map(user => (
            <button 
              key={user.id}
              onClick={() => setSelectedUser(user)}
              className={`w-full p-4 flex items-center gap-4 hover:bg-gray-50 transition-colors ${selectedUser?.id === user.id ? 'bg-indigo-50' : ''}`}
            >
              <img src={user.profile_pic} className="w-12 h-12 rounded-full object-cover border" alt="" />
              <div className="text-left overflow-hidden">
                <p className="font-semibold truncate">{user.display_name}</p>
                <p className="text-xs text-gray-500 truncate">@{user.username}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col bg-gray-50/30">
        {selectedUser ? (
          <>
            <div className="p-4 border-b bg-white flex items-center gap-4">
              <img src={selectedUser.profile_pic} className="w-10 h-10 rounded-full object-cover border" alt="" />
              <div>
                <p className="font-bold text-sm">{selectedUser.display_name}</p>
                <p className="text-[10px] text-green-500 font-bold uppercase tracking-widest">Online</p>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.map(msg => (
                <div key={msg.id} className={`flex ${msg.sender_id === currentUser.id ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[70%] p-4 rounded-2xl shadow-sm ${
                    msg.sender_id === currentUser.id 
                      ? 'bg-indigo-600 text-white rounded-tr-none' 
                      : 'bg-white text-gray-800 rounded-tl-none border'
                  }`}>
                    <p className="text-sm">{msg.text}</p>
                    <p className={`text-[10px] mt-1 ${msg.sender_id === currentUser.id ? 'text-indigo-200' : 'text-gray-400'}`}>
                      {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}
              <div ref={scrollRef} />
            </div>
            <div className="p-4 bg-white border-t">
              <div className="flex gap-2">
                <input 
                  type="text" 
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  className="flex-1 bg-gray-100 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <button 
                  onClick={handleSend}
                  className="bg-indigo-600 text-white p-3 rounded-xl hover:bg-indigo-700 transition-colors"
                >
                  <Send size={20} />
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-gray-400">
            <MessageCircle size={64} className="mb-4 opacity-20" />
            <p>Select a user to start chatting</p>
          </div>
        )}
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [currentUser, setCurrentUser] = useState<UserType | null>(null);
  const [posts, setPosts] = useState<PostType[]>([]);
  const [stories, setStories] = useState<StoryType[]>([]);
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const [userRes, feedRes, storiesRes] = await Promise.all([
      fetch('/api/users/me'),
      fetch('/api/feed'),
      fetch('/api/stories')
    ]);
    
    setCurrentUser(await userRes.json());
    setPosts(await feedRes.json());
    setStories(await storiesRes.json());
  };

  const handleCreatePost = async (type: 'post' | 'reel', url: string, caption: string) => {
    if (!currentUser) return;
    const res = await fetch('/api/posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_id: currentUser.id,
        type,
        content_url: url,
        caption
      })
    });
    if (res.ok) fetchData();
  };

  const handleAddStory = async () => {
    if (!currentUser) return;
    // For demo, just use a random image
    const res = await fetch('/api/stories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_id: currentUser.id,
        content_url: `https://picsum.photos/seed/${Math.random()}/1080/1920`
      })
    });
    if (res.ok) fetchData();
  };

  const handleUpdateProfile = async (data: Partial<UserType>) => {
    if (!currentUser) return;
    const res = await fetch('/api/users/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...currentUser, ...data })
    });
    if (res.ok) fetchData();
  };

  const handleFollow = async (id: number) => {
    if (!currentUser) return;
    await fetch('/api/follow', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ follower_id: currentUser.id, following_id: id })
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans pb-20 md:pb-0">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} currentUser={currentUser} />
        
        <main className="flex-1 min-h-screen p-4 md:p-8">
          <AnimatePresence mode="wait">
            {activeTab === 'home' && (
              <motion.div 
                key="home"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="max-w-2xl mx-auto"
              >
                <StoryBar stories={stories} onAddStory={handleAddStory} />
                <div className="mt-8">
                  {posts.map(post => (
                    <Post key={post.id} post={post} />
                  ))}
                  {posts.length === 0 && (
                    <div className="text-center py-20 text-gray-400">
                      <p className="text-lg">No posts yet. Be the first to share!</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {activeTab === 'search' && (
              <motion.div key="search" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <SearchPage onFollow={handleFollow} />
              </motion.div>
            )}

            {activeTab === 'create' && (
              <motion.div key="create" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center justify-center h-[80vh]">
                <div className="text-center">
                  <PlusSquare size={80} className="mx-auto mb-6 text-indigo-200" />
                  <h2 className="text-2xl font-bold mb-4">Share something new</h2>
                  <button 
                    onClick={() => setIsCreateOpen(true)}
                    className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-200 transition-all"
                  >
                    Open Creator
                  </button>
                </div>
              </motion.div>
            )}

            {activeTab === 'messages' && currentUser && (
              <motion.div key="messages" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <MessagesPage currentUser={currentUser} />
              </motion.div>
            )}

            {activeTab === 'profile' && currentUser && (
              <motion.div key="profile" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <ProfilePage user={currentUser} onUpdate={handleUpdateProfile} />
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      <CreateModal 
        isOpen={isCreateOpen} 
        onClose={() => setIsCreateOpen(false)} 
        onPost={handleCreatePost}
        currentUser={currentUser}
      />
    </div>
  );
}
