import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const db = new Database("social.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    display_name TEXT,
    profile_pic TEXT,
    bio TEXT
  );

  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    type TEXT, -- 'post' or 'reel'
    content_url TEXT,
    caption TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS stories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    content_url TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS follows (
    follower_id INTEGER,
    following_id INTEGER,
    PRIMARY KEY(follower_id, following_id),
    FOREIGN KEY(follower_id) REFERENCES users(id),
    FOREIGN KEY(following_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER,
    receiver_id INTEGER,
    text TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(sender_id) REFERENCES users(id),
    FOREIGN KEY(receiver_id) REFERENCES users(id)
  );
`);

// Seed a default user if none exists
const userCount = db.prepare("SELECT COUNT(*) as count FROM users").get() as { count: number };
if (userCount.count === 0) {
  db.prepare("INSERT INTO users (username, display_name, profile_pic, bio) VALUES (?, ?, ?, ?)").run(
    "johndoe",
    "John Doe",
    "https://picsum.photos/seed/john/200",
    "Social media enthusiast"
  );
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '50mb' }));

  const PORT = 3000;

  // API Routes
  app.get("/api/users/me", (req, res) => {
    const user = db.prepare("SELECT * FROM users LIMIT 1").get();
    res.json(user);
  });

  app.post("/api/users/update", (req, res) => {
    const { id, display_name, profile_pic, bio } = req.body;
    db.prepare("UPDATE users SET display_name = ?, profile_pic = ?, bio = ? WHERE id = ?").run(
      display_name,
      profile_pic,
      bio,
      id
    );
    res.json({ success: true });
  });

  app.get("/api/users/search", (req, res) => {
    const { q } = req.query;
    const users = db.prepare("SELECT * FROM users WHERE username LIKE ? OR display_name LIKE ?").all(`%${q}%`, `%${q}%`);
    res.json(users);
  });

  app.get("/api/feed", (req, res) => {
    const posts = db.prepare(`
      SELECT posts.*, users.display_name, users.profile_pic, users.username 
      FROM posts 
      JOIN users ON posts.user_id = users.id 
      ORDER BY created_at DESC
    `).all();
    res.json(posts);
  });

  app.post("/api/posts", (req, res) => {
    const { user_id, type, content_url, caption } = req.body;
    db.prepare("INSERT INTO posts (user_id, type, content_url, caption) VALUES (?, ?, ?, ?)").run(
      user_id,
      type,
      content_url,
      caption
    );
    res.json({ success: true });
  });

  app.get("/api/stories", (req, res) => {
    // In a real app, we'd filter by last 24h
    const stories = db.prepare(`
      SELECT stories.*, users.display_name, users.profile_pic 
      FROM stories 
      JOIN users ON stories.user_id = users.id 
      ORDER BY created_at DESC
    `).all();
    res.json(stories);
  });

  app.post("/api/stories", (req, res) => {
    const { user_id, content_url } = req.body;
    db.prepare("INSERT INTO stories (user_id, content_url) VALUES (?, ?)").run(user_id, content_url);
    res.json({ success: true });
  });

  app.get("/api/messages/:userId/:otherId", (req, res) => {
    const { userId, otherId } = req.params;
    const messages = db.prepare(`
      SELECT * FROM messages 
      WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
      ORDER BY created_at ASC
    `).all(userId, otherId, otherId, userId);
    res.json(messages);
  });

  app.post("/api/messages", (req, res) => {
    const { sender_id, receiver_id, text } = req.body;
    db.prepare("INSERT INTO messages (sender_id, receiver_id, text) VALUES (?, ?, ?)").run(
      sender_id,
      receiver_id,
      text
    );
    res.json({ success: true });
  });

  app.post("/api/follow", (req, res) => {
    const { follower_id, following_id } = req.body;
    try {
      db.prepare("INSERT INTO follows (follower_id, following_id) VALUES (?, ?)").run(follower_id, following_id);
      res.json({ success: true });
    } catch (e) {
      db.prepare("DELETE FROM follows WHERE follower_id = ? AND following_id = ?").run(follower_id, following_id);
      res.json({ success: true, unfollowed: true });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve("dist/index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
